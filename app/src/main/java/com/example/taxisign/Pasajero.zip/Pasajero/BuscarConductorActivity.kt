package com.example.taxisign.pasajero

import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.animation.AnimationUtils
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.taxisign.R

class BuscarConductorActivity : AppCompatActivity() {

    private var vibrator: Vibrator? = null

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.buscar_conductor)

        vibrator =
            getSystemService(VIBRATOR_SERVICE) as? Vibrator

        val radar =
            findViewById<ImageView>(R.id.iv_radar)

        val animacionRadar =
            AnimationUtils.loadAnimation(
                this,
                R.anim.rotate_radar
            )

        radar.startAnimation(animacionRadar)

        findViewById<ImageButton>(
            R.id.btn_back_busqueda
        ).setOnClickListener {

            vibrar()

            finish()
        }

        findViewById<LinearLayout>(
            R.id.btn_cancelar_busqueda
        ).setOnClickListener {

            vibrar()

            Toast.makeText(
                this,
                "Solicitud cancelada",
                Toast.LENGTH_SHORT
            ).show()

            finish()
        }
    }

    private fun vibrar() {

        vibrator?.let {

            if (!it.hasVibrator()) return

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                it.vibrate(
                    VibrationEffect.createOneShot(
                        80,
                        VibrationEffect.DEFAULT_AMPLITUDE
                    )
                )

            } else {

                @Suppress("DEPRECATION")

                it.vibrate(80)
            }
        }
    }
}