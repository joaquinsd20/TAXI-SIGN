package com.example.taxisign.pasajero

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.taxisign.MensajesActivity
import com.example.taxisign.R
import com.example.taxisign.SessionManager
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.android.gms.maps.model.MarkerOptions

class PanelPasajeroActivity :
    AppCompatActivity(),
    OnMapReadyCallback {

    private var vibrator: Vibrator? = null

    private lateinit var mMap: GoogleMap

    private lateinit var destinoLauncher:
            ActivityResultLauncher<Intent>

    private lateinit var btnMiUbicacion: ImageButton

    private lateinit var progressUbicacion: ProgressBar

    private lateinit var txtUsuario: TextView

    private lateinit var btnMenu: ImageButton

    private lateinit var layoutBuscar: LinearLayout

    private lateinit var chipCasa: LinearLayout

    private lateinit var chipTrabajo: LinearLayout

    private lateinit var btnPedirTaxi: LinearLayout

    private lateinit var tabInicio: LinearLayout

    private lateinit var tabViajes: LinearLayout

    private lateinit var tabMensajes: LinearLayout

    private lateinit var tabPerfil: LinearLayout
    companion object {

        var ultimaLatitud = -8.111763

        var ultimaLongitud = -79.028687

        var ultimoZoom = 17f
    }

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {

        super.onCreate(savedInstanceState)

        setContentView(
            R.layout.panel_pasajero
        )

        // MAPA

        val mapFragment =
            supportFragmentManager
                .findFragmentById(R.id.map)
                    as SupportMapFragment

        mapFragment.getMapAsync(this)

        vibrator =
            getSystemService(
                VIBRATOR_SERVICE
            ) as? Vibrator

        // REFERENCIAS

        progressUbicacion =
            findViewById(
                R.id.progress_ubicacion
            )

        txtUsuario =
            findViewById(
                R.id.txtUsuario
            )

        btnMenu =
            findViewById(
                R.id.btn_menu
            )

        btnMiUbicacion =
            findViewById(
                R.id.btnMiUbicacion
            )

        layoutBuscar =
            findViewById(
                R.id.layout_buscar
            )

        chipCasa =
            findViewById(
                R.id.chip_casa
            )

        chipTrabajo =
            findViewById(
                R.id.chip_trabajo
            )

        btnPedirTaxi =
            findViewById(
                R.id.btn_pedir_taxi
            )

        tabInicio =
            findViewById(
                R.id.tab_inicio
            )

        tabViajes =
            findViewById(
                R.id.tab_viajes
            )

        tabMensajes =
            findViewById(
                R.id.tab_mensajes
            )

        tabPerfil =
            findViewById(
                R.id.tab_perfil
            )

        progressUbicacion.visibility =
            View.GONE

        // VALIDAR SESIÓN

        if (
            SessionManager.idUsuario == 0
        ) {

            Toast.makeText(
                this,
                "Debes iniciar sesión",
                Toast.LENGTH_SHORT
            ).show()

            finish()

            return
        }

        // MOSTRAR NOMBRE

        txtUsuario.text =
            "¡Hola, ${SessionManager.nombreUsuario}!"

        // RECIBIR DESTINO

        destinoLauncher =
            registerForActivityResult(
                ActivityResultContracts.StartActivityForResult()
            ) { result ->

                if (result.resultCode == RESULT_OK) {

                    val data =
                        result.data

                    val latitud =
                        data?.getDoubleExtra(
                            "latitud_destino",
                            0.0
                        ) ?: 0.0

                    val longitud =
                        data?.getDoubleExtra(
                            "longitud_destino",
                            0.0
                        ) ?: 0.0

                    val direccion =
                        data?.getStringExtra(
                            "direccion_destino"
                        ) ?: ""

                    moverMapaADestino(
                        latitud,
                        longitud,
                        direccion
                    )
                }
            }

        // BOTÓN GPS

        btnMiUbicacion.setOnClickListener {

            vibrarConfirmacion()

            moverAMiUbicacion()
        }

        // MENÚ

        btnMenu.setOnClickListener {

            vibrarConfirmacion()

            Toast.makeText(
                this,
                "Menú de usuario",
                Toast.LENGTH_SHORT
            ).show()
        }

        // BUSCAR DESTINO

        layoutBuscar.setOnClickListener {

            vibrarConfirmacion()

            destinoLauncher.launch(
                Intent(
                    this,
                    BuscarDestinoActivity::class.java
                )
            )
        }

        // CASA

        chipCasa.setOnClickListener {

            vibrarConfirmacion()

            actualizarDestinoVisual(
                "Casa"
            )
        }

        // TRABAJO

        chipTrabajo.setOnClickListener {

            vibrarConfirmacion()

            actualizarDestinoVisual(
                "Trabajo"
            )
        }

        // PEDIR TAXI

        btnPedirTaxi.setOnClickListener {

            vibrarConfirmacion()

            startActivity(
                Intent(
                    this,
                    BuscarConductorActivity::class.java
                )
            )
        }

        // VIAJES

        tabViajes.setOnClickListener {

            vibrarConfirmacion()

            startActivity(
                Intent(
                    this,
                    ConductorAsignadoActivity::class.java
                )
            )
        }

        // MENSAJES

        tabMensajes.setOnClickListener {

            vibrarConfirmacion()

            startActivity(
                Intent(
                    this,
                    MensajesActivity::class.java
                )
            )
        }

        // PERFIL

        tabPerfil.setOnClickListener {

            vibrarConfirmacion()

            startActivity(
                Intent(
                    this,
                    PerfilPasajeroActivity::class.java
                )
            )
        }
    }

    override fun onMapReady(
        googleMap: GoogleMap
    ) {

        mMap = googleMap

        // MAPA OSCURO

        mMap.setMapStyle(
            MapStyleOptions.loadRawResourceStyle(
                this,
                R.raw.map_style_dark
            )
        )

        // UI MAPS

        mMap.uiSettings.isZoomControlsEnabled =
            false

        mMap.uiSettings.isCompassEnabled =
            false

        mMap.uiSettings.isMapToolbarEnabled =
            false

        mMap.uiSettings.isMyLocationButtonEnabled =
            false

        // GUARDAR POSICIÓN ACTUAL DEL MAPA

        mMap.setOnCameraIdleListener {

            val camera =
                mMap.cameraPosition

            ultimaLatitud =
                camera.target.latitude

            ultimaLongitud =
                camera.target.longitude

            ultimoZoom =
                camera.zoom
        }

        // RESTAURAR ÚLTIMA POSICIÓN

        val ultimaUbicacion =
            LatLng(
                ultimaLatitud,
                ultimaLongitud
            )

        mMap.moveCamera(
            CameraUpdateFactory.newLatLngZoom(
                ultimaUbicacion,
                ultimoZoom
            )
        )

        // VALIDAR PERMISOS

        if (
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION
                ),
                1001
            )

            return
        }

        // ACTIVAR UBICACIÓN

        mMap.isMyLocationEnabled = true
    }

    private fun moverAMiUbicacion() {

        if (
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val fusedLocationClient =
            LocationServices
                .getFusedLocationProviderClient(this)

        fusedLocationClient.lastLocation
            .addOnSuccessListener { location ->

                if (location != null) {

                    ultimaLatitud =
                        location.latitude

                    ultimaLongitud =
                        location.longitude

                    ultimoZoom =
                        17f

                    val miUbicacion =
                        LatLng(
                            location.latitude,
                            location.longitude
                        )

                    mMap.animateCamera(
                        CameraUpdateFactory.newLatLngZoom(
                            miUbicacion,
                            17f
                        )
                    )
                }
            }
    }

    private fun moverMapaADestino(
        latitud: Double,
        longitud: Double,
        direccion: String
    ) {

        ultimaLatitud = latitud

        ultimaLongitud = longitud

        ultimoZoom = 17f

        val destino =
            LatLng(
                latitud,
                longitud
            )

        mMap.clear()

        mMap.addMarker(
            MarkerOptions()
                .position(destino)
                .title(direccion)
        )

        mMap.animateCamera(
            CameraUpdateFactory.newLatLngZoom(
                destino,
                17f
            )
        )

        Toast.makeText(
            this,
            direccion,
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun actualizarDestinoVisual(
        destino: String
    ) {

        Toast.makeText(
            this,
            "Destino seleccionado: $destino",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun vibrarConfirmacion() {

        vibrator?.let {

            if (!it.hasVibrator()) return

            if (
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.O
            ) {

                it.vibrate(
                    VibrationEffect.createOneShot(
                        60,
                        VibrationEffect.DEFAULT_AMPLITUDE
                    )
                )

            } else {

                @Suppress("DEPRECATION")

                it.vibrate(60)
            }
        }
    }
}