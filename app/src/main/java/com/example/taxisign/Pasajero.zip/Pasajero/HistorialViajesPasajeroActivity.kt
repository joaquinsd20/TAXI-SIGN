package com.example.taxisign.pasajero

import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.taxisign.R

class HistorialViajesPasajeroActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_historial_viajes_pasajero)

        val btnBack = findViewById<ImageButton>(R.id.btn_back)
        val recycler = findViewById<RecyclerView>(R.id.recycler_historial)

        btnBack.setOnClickListener {
            finish()
        }

        val listaViajes = listOf(

            Viaje(
                "Universidad Nacional de Trujillo",
                "17/05/2026 - 8:30 PM",
                "Completado"
            ),

            Viaje(
                "Mall Plaza Trujillo",
                "16/05/2026 - 6:10 PM",
                "Completado"
            ),

            Viaje(
                "Aeropuerto de Trujillo",
                "15/05/2026 - 11:45 AM",
                "Completado"
            )

        )

        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = HistorialViajesAdapter(listaViajes)

    }
}